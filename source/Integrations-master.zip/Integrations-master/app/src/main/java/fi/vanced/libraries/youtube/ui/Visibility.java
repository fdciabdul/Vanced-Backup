package fi.vanced.libraries.youtube.ui;

public enum Visibility {
    NONE,
    PLAYER,
    BUTTON_CONTAINER,
    BOTH,
}
