package fi.razerman.youtube;

// Ignore this file, the implementation is in another repository
public class XGlobals {
    public static Boolean debug = false;
}
