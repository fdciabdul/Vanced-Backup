export default {
	online: 'https://i.imgur.com/FS5nWDJ.png',
	idle: 'https://i.imgur.com/7mC8AWy.png',
	dnd: 'https://i.imgur.com/EdvCkvZ.png',
	offline: 'https://i.imgur.com/YQNx8dT.png',
	invisible: 'https://i.imgur.com/YQNx8dT.png',
	streaming: 'https://i.imgur.com/xutQKUO.png'
};
