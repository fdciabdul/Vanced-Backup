package network.model.genderapi

data class GenderDto(
    val gender: String,
    val accuracy: Int
)
