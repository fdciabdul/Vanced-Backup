package core.database.collections

data class Emote(
    val guildId: String,
    val emote: String,
    val usedCount: Int
)
