package core.util

const val EMOTE_STONKS = "<:stonks:635003250759958569>"
const val EMOTE_STINKS = "<:stinks:639524149361901576>"
const val EMOTE_RELAX = "<:relax:673135590769688586>"
const val EMOTE_FEELS = "<:feels:622146675095371776>"
const val EMOTE_SADNESS = "<:sadness:651054041245155328>"
const val EMOTE_V_MERCHANT = "<:V_merchant:797323789918011432>"
const val EMOTE_PRESS_F = "<:pressF:657676117779415050>"