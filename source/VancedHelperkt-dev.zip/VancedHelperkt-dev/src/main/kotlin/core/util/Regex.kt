package core.util

val emoteRegex = "<?(a)?:?(\\w{2,32}):(\\d{17,19})>?".toRegex()