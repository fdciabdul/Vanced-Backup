## VancedHelper.kt

Discord Bot written in Kotlin for the [Vanced Discord Server](https://discord.gg/v2REwvu)