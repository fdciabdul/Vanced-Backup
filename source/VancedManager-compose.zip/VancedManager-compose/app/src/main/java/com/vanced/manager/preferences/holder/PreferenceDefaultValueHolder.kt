package com.vanced.manager.preferences.holder

const val MANAGER_VARIANT_DEFAULT_VALUE = "nonroot"

const val MANAGER_THEME_DEFAULT_VALUE = "System Default"

const val VANCED_THEME_DEFAULT_VALUE = "dark"
val VANCED_LANGUAGE_DEFAULT_VALUE = setOf("en")

const val APP_VERSION_DEFAULT_VALUE = "latest"

const val APP_ENABLED_DEFAULT_VALUE = true