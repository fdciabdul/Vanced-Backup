package com.vanced.manager.ui.util

import androidx.compose.ui.unit.dp

val DefaultContentPaddingHorizontal = 16.dp
val DefaultContentPaddingVertical = 12.dp

val EdgeToEdgeContentPadding = 8.dp