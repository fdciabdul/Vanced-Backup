---
name: Feature Request Template
about: Vanced Manager Feature Request Template
title: ''
labels: 'enhancement'
assignees: ''

---

**Please only open the issue if the following is true**
- This is an issue in the Vanced Manager and ONLY Vanced Manager (NOT Youtube Vanced/Music/microG)

**Suggestion:**

**Why is this suggestion relevant?**

**Further details:**
