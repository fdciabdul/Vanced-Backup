package fi.vanced.libraries.youtube.ryd;

public class RYDSettings {
    public static final String PREFERENCES_NAME = "ryd";
    public static final String PREFERENCES_KEY_USERID = "userId";
    public static final String PREFERENCES_KEY_RYD_ENABLED = "ryd-enabled";
    public static final String PREFERENCES_KEY_RYD_HINT_SHOWN = "ryd_hint_shown";
}
