#!/bin/sh
exec java -jar /src/build/libs/bot.jar
