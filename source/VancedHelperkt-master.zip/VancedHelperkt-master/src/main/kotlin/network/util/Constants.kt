package network.util

const val baseGuideUrl = "https://vancedapp.com/webapi/strings/"
const val genderApiUrl = "https://gender-api.com/"
const val coinlibApiUrl = "https://coinlib.io/api/v1/"