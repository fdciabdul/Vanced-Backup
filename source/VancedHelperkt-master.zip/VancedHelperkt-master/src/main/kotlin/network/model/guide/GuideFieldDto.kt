package network.model.guide

data class GuideFieldDto(
    val title: String,
    val content: String
)
