package core.database.collections

data class QuoteRoles(
    val allowedRoleIds: List<String>
)