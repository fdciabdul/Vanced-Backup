package core.util

val botOwners = arrayOf(
    202115709231300617UL, //xfile
    256143257472335872UL, //Kevin
    423915768191647755UL, //Xinto
)