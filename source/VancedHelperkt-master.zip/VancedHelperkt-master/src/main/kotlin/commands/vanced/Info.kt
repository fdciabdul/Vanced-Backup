package commands.vanced

import core.command.base.BaseGuideCommand

class Info : BaseGuideCommand(
    commandName = "info",
    commandDescription = "Vanced FAQ",
    jsonName = "faq",
)