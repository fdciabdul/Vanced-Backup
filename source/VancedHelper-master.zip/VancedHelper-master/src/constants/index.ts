import regex from './regex';
import statusIcons from './statusIcons';
import animeQuery from './animeQuery';
import emojis from './emojis';

export default {
	regex,
	statusIcons,
	animeQuery,
	emojis
};
