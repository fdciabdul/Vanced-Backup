---
name: Question
about: You have a question about something in Vanced
title: '[Question] replaceme'
labels: 'question'
assignees: ''

---

<!-- MANAGER/MICROG/VANCED MUSIC ISSUES DO NOT BELONG HERE, READ THE README FOR MORE INFO -->

**Description**
Replace me with a clear and detailed description of the question.


_Attach images/videos if possible. These can be helpful in figuring out what the question is about._
