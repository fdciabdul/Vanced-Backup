---
name: Feature request
about: You have a feature you would like in Vanced
title: '[Idea] replaceme'
labels: 'enhancement'
assignees: ''

---

<!-- MANAGER/MICROG/VANCED MUSIC ISSUES DO NOT BELONG HERE, READ THE README FOR MORE INFO -->

**Description**
Replace me with a clear and detailed description of the idea.


_Attach images/videos if possible. Also add any links to possible other applications with the said feature already implemented._
