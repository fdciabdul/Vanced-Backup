package fi.razerman.youtube.Helpers;

import android.view.ViewGroup;

public class XSwipeHelper {
    // Implementation in another repo
    public static ViewGroup nextGenWatchLayout;
}