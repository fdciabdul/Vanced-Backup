package fi.vanced.libraries.youtube.player;

public class VideoInformation {
    public static String currentVideoId;
    public static long lastKnownVideoTime = -1L;
}
