package com.vanced.manager.model

data class NotifModel(
    val topic: String,
    val switchTitle: String,
    val switchSummary: String,
    val key: String
)