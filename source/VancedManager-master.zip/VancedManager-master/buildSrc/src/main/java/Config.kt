object Config {

    const val kotlinVersion = "1.4.21"

}