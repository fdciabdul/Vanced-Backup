package db

data class Apk(
    val fileName: String,
    val url: String,
)