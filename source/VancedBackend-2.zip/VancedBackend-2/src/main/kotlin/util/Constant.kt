package util

const val API_BASE = "https://api.vancedapp.com/v2"
const val API_GITHUB_BASE = "https://api.github.com"