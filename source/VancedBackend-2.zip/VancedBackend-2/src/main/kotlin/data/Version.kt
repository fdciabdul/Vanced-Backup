package data

data class Version(
    val versionName: String,
    val versionCode: Int,
)
