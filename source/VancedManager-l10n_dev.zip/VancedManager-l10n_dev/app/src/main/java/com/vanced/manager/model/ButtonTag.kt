package com.vanced.manager.model

enum class ButtonTag {
    INSTALL, UPDATE, REINSTALL
}