export const BRAVE = "https://vancedapp.com/brave";
export const ADGUARD = "https://adguard.com/en/welcome.html?aid=31141";
